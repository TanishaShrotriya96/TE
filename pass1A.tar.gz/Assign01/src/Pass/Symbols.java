package Pass;

public class Symbols {
	String name;
	int addr;
    
	
	public Symbols(){

		name=null;
		addr=0;
		
	}
	
	public String toString(){
		return name + " " + addr +"\n";
		
	}
}
